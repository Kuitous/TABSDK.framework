//
//  TabBarController.h
//  TabBarAnimation
//
//  Created by 袁小荣 on 2018/8/24.
//  Copyright © 2018年 Bruceyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JXYTABViewController : UITabBarController
/*
 TAB 底部不带文字
 */
- (void)addVcWithPurefigure:(UIViewController *)vc;
/*
 TAB 底部带文字
 vc         :视图vc
 VCtoptitle ：底部文字
 hexColor   ：底部文字未选中状态颜色
 hexColor1  ：底部文字选中状态颜色
 font       ：底部文字大小 ，一般10左右
 */
-(void)AddVcWithTopText:(UIViewController *)vc VC_Top_title:(NSString *)VCtoptitle titleSelected_NO_Color:(long)hexColor titleSelected_YES_Color:(long)hexColor1 titleFont:(UIFont *)font;
@end
