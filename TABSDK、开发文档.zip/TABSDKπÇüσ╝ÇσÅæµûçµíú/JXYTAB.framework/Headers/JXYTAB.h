//
//  JXYTAB.h
//  JXYTAB
//
//  Created by 公司的MACPro on 2019/7/23.
//  Copyright © 2019 公司的MACPro. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for JXYTAB.
FOUNDATION_EXPORT double JXYTABVersionNumber;

//! Project version string for JXYTAB.
FOUNDATION_EXPORT const unsigned char JXYTABVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JXYTAB/PublicHeader.h>
#import <JXYTAB/JXYTABViewController.h>

